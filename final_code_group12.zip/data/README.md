# Datasets
There are 4 primary data sources
- ABS Data (Population, Income) by SA2 Level
- Scraped rental properties from domain.com.au
- Postcodes and their respective names from https://postcodes-australia.com/state-postcodes/vic
- Shapefiles for public transport stops from PTV Australia
