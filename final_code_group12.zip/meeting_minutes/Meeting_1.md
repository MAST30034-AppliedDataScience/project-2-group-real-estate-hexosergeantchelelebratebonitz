## Project 2 Meeting 1 Minutes
Minutes (20/08/2024 2:45pm)
## Attendees:
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)
## Agenda:
- Which project to undertake?
- General Timeline
**Chosen Topic:** Real Estate Industry Project
There was a general concensus that the real estate project was more interesting and applicable to not
only real life but our individual predicament in the rental crisis.
## General Timeline:
In line with the project checkpoints provided to us at the moment.
