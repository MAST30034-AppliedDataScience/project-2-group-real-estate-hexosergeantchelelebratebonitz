# Project 2 Meeting 6 Minutes
Minutes (26/09/2024 Tuesday 2:15pm)

## Group 12 Members: 
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)

## Agenda:
* Finish 3 year model
* Summary notebook

## To-do Next:
* Aarav: Income/Population by SA2 instead of suburb.  Forcast 2024, 2025, 2026 for both population and income.
* Can and Julian: Create a model to predict rental prices (2018, 2019, 2020, 2021, 2022, 2023)

## Signed: 
4 members were present on 23/09/2024:
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)
