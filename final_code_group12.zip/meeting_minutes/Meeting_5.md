# Project 4 Meeting 5 Minutes
Minutes (17/09/2024 Tuesday 2:15pm)

## Group 12 Members: 
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)

## Agenda:
* Find longtitude and latitude data from Street Address
* Find location of public transport stops
* Find proximity values for properties to public transport
* Preprocess data

## To-do Next:
* Julian: Proximity to shopping centres
* Can: Proximity to public transport
* Michele: Proximity to supermarkets
* Aarav: Proximity to public transport / some preprocessing

## Signed: 
All members were present on Tuesday 17/09/2024:
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)
