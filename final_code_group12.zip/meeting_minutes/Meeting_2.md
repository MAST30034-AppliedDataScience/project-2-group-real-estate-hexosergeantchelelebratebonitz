## Project 2 Meeting 2 Minutes
Minutes (27/08/2024 2:40pm)
## Attendees:
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)
## Agenda:
- Meeting 1 Submission (we submitted early)
- Start scraping (Julian and Aarav)
- Make Shapefile (Cun and Michele)
## General Timeline:
- Julian and Aarav will begin scraping websites for data.
- Cun and Michele will make a shapefile and/or a way of visualising geolocations of the property.
