# Project 2 Meeting 7 Minutes
Minutes (1/10/2024 Tuesday 2:15pm)

## Group 12 Members: 
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)

## Agenda:
* To-do list
* Discuss Presentation
* Next Meeting: Sunday 6th October 2pm

## To-do Next:
* Julian: Rental Forecasting, Presentation
* Can: Rental Forecasting, Presentation
* Aarav: Work on property-based model, Presentation Layout, 
* Michele: Rental Forecasting, Summary Notebook, Presentation

## Signed: 
4 members were present on 1/10/2024:
1. Julian Bonitz (1067373)
2. Can Senyurt (1079752)
3. Michele Sembiring Meliala (1342923)
4. Aarav Nair (1287210)
